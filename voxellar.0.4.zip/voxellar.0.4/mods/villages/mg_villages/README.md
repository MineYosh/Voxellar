This is a continuation of my (Sokomines) fork of Nores mg mapgen.
The fork can be found under https://github.com/Sokomine/mg

