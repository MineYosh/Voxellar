
Experimental snow for stairs, slabs and nodeboxes (to a degree).
Due to the very nature of nodes in Minetest, the snow cannot
handle all situations. Moresnow is made for roofs (which do look
better with a snow cover in winter), slabs, fences etc.

The texture for the winter leaves (the snowy ones) is taken from Moontest,
which can be found at https://github.com/Amaz1/moontest/tree/master/mods/moontest
