Version: 3.3

The tool is a weapon at same time
Throw it and it will always return as long there still is velocity/power left
It can pick up stuff that is breakable by hand (like no use by tools) and mobs/drops that have 10hp or less.
Players (or mobs that have more then 10 hp) will be hurted.

+ Mese can break more stuff, more times at same throw, and can break stuff like stone / ores, makes a flash when hit something (usefull in darknes / caves)

- Wood cant pick up stuff, hurt less, it fail if it hit hard block.


Craft: Wood:
S = Stick
w = Wood
[S] [  ] [S]
[  ] [w] [  ]
[S] [  ] [S]

Craft: Steel:
S = Steel ingot
B = Steel block
[S] [  ] [S]
[  ] [B] [  ]
[S] [  ] [S]

Craft: Mese:
C = Mese crystal
B = Mese block
[C] [  ] [C]
[  ] [B] [  ]
[C] [  ] [C]






