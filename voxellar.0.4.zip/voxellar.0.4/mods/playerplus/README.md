PlayerPlus mod for minetest

This mod lets the player walk faster when walking on ice, slows down the player when waling on snow or in water, and makes touching a cactus hurt... enjoy

https://forum.minetest.net/viewtopic.php?t=10090&p=153667

0.1 - Initial release
0.2 - 3d_armor mod compatibility
0.3 - Optimized code
0.4 - Added suffocation when inside nodes
0.5 - Slow down when walking in water
0.6 - Code tidy and tweak, increased damage by cactus and suffocation

Released under WTFPL