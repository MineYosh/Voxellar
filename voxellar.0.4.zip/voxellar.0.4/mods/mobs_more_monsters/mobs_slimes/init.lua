
if mobs.mod and mobs.mod == "redo" then

	local path = minetest.get_modpath("mobs_slimes")
	dofile(path.."/greenslimes.lua")
	dofile(path.."/lavaslimes.lua")

end
