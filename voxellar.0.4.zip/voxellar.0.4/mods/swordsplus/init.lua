--
-- Swords
--

minetest.register_tool("swordsplus:tomahawk", {
	description = "tomahawk",
	inventory_image = "swordsplus_tomahawk.png",
	tool_capabilities = {
		full_punch_interval = 1.2,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=9},
	}
})

minetest.register_craft({
	output = 'swordsplus:tomahawk',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', ''},
	}
})

minetest.register_tool("swordsplus:gsword", {
	description = "golden sword",
	inventory_image = "swordsplus_gsword.png",
	tool_capabilities = {
		full_punch_interval = 0.25,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=8},
	}
})

minetest.register_craft({
	output = 'swordsplus:gsword',
	recipe = {
		{'default:gold_ingot'},
		{'default:gold_ingot'},
		{'default:mese_crystal'},
	}
})

minetest.register_tool("swordsplus:bbat", {
	description = "baseball bat",
	inventory_image = "swordsplus_bbat.png",
	tool_capabilities = {
		full_punch_interval = 2.25,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=10},
	}
})

minetest.register_craft({
	output = 'swordsplus:bbat',
	recipe = {
		{'default:tree'},
		{'default:tree'},
		{'default:stick'},
	}
})

minetest.register_tool("swordsplus:bhammer", {
	description = "battle hammer",
	inventory_image = "swordsplus_bhammer.png",
	tool_capabilities = {
		full_punch_interval = 5.75,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=35},
	}
})

minetest.register_craft({
	output = 'swordsplus:bhammer',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'default:tree', ''},

	}
})

minetest.register_tool("swordsplus:dagger", {
	description = "dagger",
	inventory_image = "swordsplus_dagger.png",
	tool_capabilities = {
		full_punch_interval = 0.0000001,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=5},
	}
})

minetest.register_craft({
	output = 'swordsplus:dagger',
	recipe = {
		{'default:steel_ingot'},
		{'default:gold_ingot'},
		{'default:diamond'},
	}
})

minetest.register_tool("swordsplus:machete", {
	description = "machete",
	inventory_image = "swordsplus_machete.png",
	tool_capabilities = {
		full_punch_interval = 0.65,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=6},
	}
})

minetest.register_craft({
	output = 'swordsplus:machete',
	recipe = {
		{'default:steel_ingot'},
		{'default:steel_ingot'},
		{'default:tree'},
	}
})

minetest.register_tool("swordsplus:ls", {
	description = "lightsaber",
	inventory_image = "swordsplus_ls.png",
	tool_capabilities = {
		full_punch_interval = 0.00001,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=100},
	}
})

minetest.register_craft({
	output = 'swordsplus:ls',
	recipe = {
		{'default:diamondblock'},
		{'default:diamondblock'},
		{'default:steel_ingot'},
	}
})

minetest.register_tool("swordsplus:longsword", {
	description = "longsword",
	inventory_image = "swordsplus_longsword.png",
	tool_capabilities = {
		full_punch_interval = 1.5,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=30, maxlevel=5},
		},
		damage_groups = {fleshy=12},
	}
})

minetest.register_craft({
	output = 'swordsplus:ls',
	recipe = {
		{'default:steel_ingot'},
		{'default:steel_ingot'},
		{'default:gold_ingot'},
	}
})







