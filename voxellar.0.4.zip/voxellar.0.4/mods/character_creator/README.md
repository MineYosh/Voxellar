This mod attribution to the Voxelands project.

Voxelands creators:
sdzen
darkrose
